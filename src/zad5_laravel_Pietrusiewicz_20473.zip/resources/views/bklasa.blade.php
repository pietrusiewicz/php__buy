@extends('layout')

@section('content')
<h1>Zespoły B-klasy WMZPN sezonu 2024/25 <br/>miejsca w tabeli po rundzie jesiennej:</h1>
<div style="float:left;width:25%;">
<p>grupa 1:</p>
<ol>
    <li>Reduta Bisztynek</li>
    <li>Vęgoria II Węgorzewo</li>
    <li>Salęt Boże</li>
    <li>Znicz II Biała Piska</li>
    <li>Szansa Reszel</li>
    <li>Start Kruklanki</li>
    <li>Start Kozłowo</li>
    <li>Orlęta II Reszel</li>
    <li>Tempo Ramsowo/Wipsowo</li>
    <li>Warmianka Bęsia</li>
</ol>
</div>
<div style="float:left;width:25%;">
<p>grupa 2:</p>
<ol>
    <li>Barkas Tolkmicko</li>
    <li>Sparta Kwietniewo</li>
    <li>Żabianka Żabi Róg</li>
    <li>GKS Małdyty</li>
    <li>Polonia II Pasłęk</li>
    <li>Granica Zagaje</li>
    <li>Pogrom Aniołowo</li>
    <li>Warmiak Łukta</li>
    <li>Potok Weklice</li>
</ol>
</div>
<div style="float:left;width:25%;">
<p>grupa 3:</p>
<ol>
    <li>Gwardia II Szczytno</li>
    <li>Burza Słupy</li>
    <li>WTKS Mierki</li>
    <li>Pisa II Barczewo</li>
    <li>Leśnik Nowe Ramuki</li>
    <li>Omulew II Wielbark</li>
    <li>Perkun II Orżyny</li>
    <li>GKS II Szczytno</li>
    <li>Zryw Jedwabno</li>
    <li>Wałpusza 07 Jesionowiec</li>
</ol>
</div>
<div style="float:left;width:25%;">
<p>grupa 4:</p>
<ol>
    <li>Iskra Smykówko</li>
    <li>Torpeda Rożental</li>
    <li>MKS II Działdowo</li>
    <li>Orzeł Ulnowo</li>
    <li>Mewa Smykowo</li>
    <li>Góra Idzbark</li>
    <li>Wel Bratian</li>
    <li>Drwęca II Nowe Miasto Lubawskie</li>
    <li>Żak Jamielnik</li>
    <li>Wicher Gwiździny</li>
    <li>Czarni II Rudzienice</li>
</ol>
</div>
<div style="clear:both">
@endsection