@extends('layout')

@section('content')
<h1>Zespoły A-klasy WMZPN sezonu 2024/25 <br/>miejsca w tabeli po rundzie jesiennej:</h1>
<div style="float:left;width:25%;">
<p>grupa 1:</p>
<ol>
    <li>Mazur Wydminy</li>
    <li>Mazur Pisz</li>
    <li>KS Wojciechy</li>
    <li>Pojezierze Prostki</li>
    <li>Żagiel Piecki</li>
    <li>Orzeł Czerwonka</li>
    <li>Pomarańcze Korsze</li>
    <li>Mamry II Giżycko</li>
    <li>Wilczek Wilkowo</li>
    <li>Łyna Sępopol</li>
    <li>Rona 03 Ełk</li>
    <li>Pogoń Ryn</li>
    <li>MKS Ruciane-Nida</li>
    <li>Jurand Barciany</li>
</ol>
</div>
<div style="float:left;width:25%;">
<p>grupa 2:</p>
<ol>
    <li>KS Tyrowo</li>
    <li>Wałsza Pieniężno</li>
    <li>Pomowiec Gronowo Elbląskie</li>
    <li>Jastrząb Ględy</li>
    <li>Agat Jegłownik</li>
    <li>Syrena Młynary</li>
    <li>Tęcza Miłomłyn</li>
    <li>Polonia Markusy</li>
    <li>Zagłada Lisów</li>
    <li>Ewingi Zalewo</li>
    <li>MKS Miłakowo</li>
    <li>Zalew Frombork</li>
    <li>Grunwald Gierzwałd</li>
    <li>Piast Wilczęta</li>
</ol>
</div>
<div style="float:left;width:25%;">
<p>grupa 3:</p>
<ol>
    <li>Warmia Olsztyn</li>
    <li>Błękitni Stary Olsztyn</li>
    <li>Warmia Wrzesina</li>
    <li>Omulew Wielbark</li>
    <li>Gmina Kozłowo</li>
    <li>GKS Szczytno</li>
    <li>FC Dajtki (Olsztyn)</li>
    <li>MKS Jeziorany</li>
    <li>Orzyc Janowo</li>
    <li>LKS Różnowo</li>
    <li>Fortuna Gągławki</li>
    <li>KS Łęgajny</li>
    <li>GLKS Jonkowo</li>
    <li>GKS Gietrzwałd/Unieszewo</li>
</ol>
</div>
<div style="float:left;width:25%;">
<p>grupa 4:</p>
<ol>
    <li>MKS Działdowo</li>
    <li>Radomniak Radomno</li>
    <li>LZS Frednowy</li>
    <li>Jordan Kazanice</li>
    <li>Rozwój Iława</li>
    <li>Olimpia Kisielice</li>
    <li>PFT Sampława</li>
    <li>Zamek Szymbark</li>
    <li>GSZS Rybno</li>
    <li>Zamek Kurzętnik</li>
    <li>KS Mroczno</li>
    <li>Vel Dąbrówno</li>
    <li>Osa Ząbrowo</li>
</ol>
</div>
<div style="clear:both">
@endsection