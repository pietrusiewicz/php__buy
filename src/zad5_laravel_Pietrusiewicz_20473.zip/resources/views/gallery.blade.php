@extends('layout')

@section('content')
<h1>Gallery</h1>
<p>Check out some amazing moments from the world of football:</p>
<img src="{{ asset('images/football.jpg') }}" alt="Football">
@endsection