@extends('layout')

@section('content')
<h1>Zespoły Klasy Okręgowej WMZPN sezonu 2024/25 <br/>miejsca w tabeli po rundzie jesiennej:</h1>
<div style="float:left;width:50%">
<p>grupa 1:</p>
<ol>
    <li>Orzeł Janowiec Kościelny</li>
    <li>GKS Stawiguda</li>
    <li>Czarni Olecko</li>
    <li>Polonia Iłowo</li>
    <li>Błękitni Pasym</li>
    <li>Śniardwy Orzysz</li>
    <li>Naki Olsztyn</li>
    <li>Kłobuk Mikołajki</li>
    <li>Iskra Narzym</li>
    <li>MKS Korsze</li>
    <li>Vęgoria Węgorzewo</li>
    <li>Gwardia Szczytno</li>
    <li>Perkun Orżyny</li>
    <li>Victoria Bartoszyce</li>
    <li>Orlęta Reszel</li>
    <li>Cresovia Górowo Iławeckie</li>
</ol>
</div>
<div style="float:left;width:50%;">
<p>grupa 2:</p>
<ol>
    <li>Zatoka Braniewo</li>
    <li>Drwęca Nowe Miasto Lubawskie</li>
    <li>Ossa Biskupiec Pomorski</li>
    <li>Polonia Pasłęk</li>
    <li>Błękitni Orneta</li>
    <li>Huragan Morąg</li>
    <li>Płomień Turznica</li>
    <li>Constract Lubawa</li>
    <li>Dąb Kadyny</li>
    <li>Kormoran Zwierzewo</li>
    <li>Motor Lubawa</li>
    <li>Czarni Rudzienice</li>
    <li>Unia Susz</li>
    <li>Olimpia III Elbląg</li>
    <li>Wel Lidzbark</li>
</ol>
</div>
<div style="clear:both">
@endsection