<!DOCTYPE html>
<html>
<head>
<title>tytuł</title>
</head>
<body>
<h1>login</h1>
<form method="POST" action="/">
    <?php echo csrf_field(); ?>
    <input type="text" name="usname"/>
    <input type="password" name="passwd"/>
    <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" />
    <input type="submit" value="Log in"/>
</form>
<h6><a href="/register">Create your account</a></h6>
<p><?php echo e($info); ?></p>
</body>
</html>
<?php /**PATH /var/www/html/resources/views/login.blade.php ENDPATH**/ ?>