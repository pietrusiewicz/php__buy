

<?php $__env->startSection('content'); ?>
<h1>Contact Us</h1>
<p>Licznik czerwonych kartek</p>
<form action="<?php echo e(route('submit-card')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <label for="yellow">żółte kartki:
    <input type="number" id="yellow" name="yellow" min=0></label>
    <label for="red">czerwone kartki:
    <input type="number" id="red" name="red" max=5 min=0></label>
    <br/>
    <button type="submit">Send</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/cards.blade.php ENDPATH**/ ?>