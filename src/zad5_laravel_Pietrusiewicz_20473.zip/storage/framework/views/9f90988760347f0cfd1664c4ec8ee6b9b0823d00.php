

<?php $__env->startSection('content'); ?>
<h1>Gallery</h1>
<p>Check out some amazing moments from the world of football:</p>
<img src="<?php echo e(asset('images/football.jpg')); ?>" alt="Football">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/gallery.blade.php ENDPATH**/ ?>