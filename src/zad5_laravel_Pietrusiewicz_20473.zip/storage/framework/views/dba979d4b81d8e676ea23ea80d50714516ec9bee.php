

<?php $__env->startSection('content'); ?>
<h1>Contact Us</h1>
<p>If you have any questions or comments, feel free to reach out to us using the form below:</p>
<form action="<?php echo e(route('handleContact')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <label for="name">Name:</label>
    <input type="text" id="name" name="name" required>
    <label for="message">Message:</label>
    <textarea id="message" name="message" required></textarea>
    <button type="submit">Send</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/resources/views/contact.blade.php ENDPATH**/ ?>