<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Piłka na Warmii i Mazurach</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
</head>
<body>
    <nav>
        <ul>
            <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
            <li><a href="<?php echo e(route('okregowa')); ?>">Klasa Okręgowa</a></li>  
            <li><a href="<?php echo e(route('aklasa')); ?>">Klasa A</a></li>          
            <li><a href="<?php echo e(route('bklasa')); ?>">Klasa B</a></li>
            <li><a href="<?php echo e(route('gallery')); ?>">Galeria</a></li>
            <li><a href="<?php echo e(route('cards')); ?>">Kartki</a></li>
        </ul>
    </nav>
    <div class="content">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
</body>
</html><?php /**PATH /var/www/html/resources/views/layout.blade.php ENDPATH**/ ?>